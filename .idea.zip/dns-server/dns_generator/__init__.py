"""
Parse various DNS messages and Generate DNS messages
"""

from .dns_generator import DNSGen
from .ClientHandler import ClientHandler
